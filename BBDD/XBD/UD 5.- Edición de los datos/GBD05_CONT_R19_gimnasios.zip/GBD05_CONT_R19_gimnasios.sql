/*************************************************************************
 Creación de la base de datos gimnasios y todas sus tablas
*************************************************************************/

/*Borramos, si existe, una base de datos anterior */
DROP DATABASE IF EXISTS gimnasios;

/*Creamos la base de datos de nombre sucursales*/
CREATE DATABASE gimnasios;


-- -------------------------------------------------------------------
--  TABLAS gimnasio, monitores, personal, categorias y puestos  -----
-- -------------------------------------------------------------------

USE gimnasios;


-- TABLA GIMNASIO

CREATE TABLE gimnasio (
 cod_gim   SMALLINT NOT NULL,
 tipo_gim  ENUM ('INF', 'MED', 'SUP') NOT NULL,
 nombre       VARCHAR(45) UNIQUE NOT NULL,
 direccion    VARCHAR(80),
 telefono     VARCHAR(15) NOT NULL,
 tarifa_base   double(9,2)  UNSIGNED NOT NULL DEFAULT 11,
 PRIMARY KEY (cod_gim)
 ) ;


-- TABLA PUESTOS
CREATE TABLE puestos(
cod_pue CHAR(3) NOT NULL PRIMARY KEY,
nombre VARCHAR(55) UNIQUE NOT NULL,
complemento FLOAT(6,2) UNSIGNED DEFAULT 0
);

-- TABLA PERSONAL

CREATE TABLE personal (  
 dni          CHAR(10) NOT NULL,  
 nombre    VARCHAR(35),
 puesto      CHAR(3),
 salario_base      FLOAT(7,2) UNSIGNED NOT NULL,
 cod_gim  SMALLINT NOT NULL,
PRIMARY KEY (dni),
FOREIGN KEY (cod_gim) 
REFERENCES gimnasio (cod_gim)
ON DELETE RESTRICT
ON UPDATE CASCADE,
FOREIGN KEY (puesto)
REFERENCES puestos (cod_pue)
ON DELETE SET NULL
ON UPDATE CASCADE
);


-- TABLA CATEGORÍAS

CREATE TABLE categorias (
cod_cat CHAR(4) NOT NULL PRIMARY KEY,
nombre VARCHAR(35) NOT NULL UNIQUE,
incentivo FLOAT(6,2) UNSIGNED DEFAULT 0
);


-- TABLA MONITORES

CREATE TABLE monitores ( 
 dni       CHAR(10) NOT NULL,
 nombre    VARCHAR(30),
 cod_gim  SMALLINT NOT NULL,
 catego CHAR(4),
 PRIMARY KEY (dni),
 FOREIGN KEY (cod_gim)
 REFERENCES gimnasio (cod_gim)
 ON DELETE RESTRICT
 ON UPDATE CASCADE,
 FOREIGN KEY (catego)
 REFERENCES categorias (cod_cat)
 ON DELETE SET NULL
 ON UPDATE CASCADE
);

-- Inserción de datos en las tablas

INSERT INTO gimnasio VALUES (10,'INF','ActivaFitness','Cangrejo, 27', '635243211',50),
(20,'INF','VivaFitness', 'Esmeralda, 18','671530970',40),
(30,'MED', 'ActivaGym ', 'Patinillos, 1','0044671530970',75),
(40,'MED', 'Kankunete', 'Perdidos, 18','0044661835910',70),
(50,'SUP', 'EgoGym', 'Maravillas, 6','655845713',81),
(60,'SUP', 'SportGym', 'Plazuelas, 2','625342743',95),
(77,'SUP', 'TopGym', 'Gran vía, 122','627121212',90)
;

INSERT INTO puestos VALUES('01', 'Comercial', 100),
('02', 'Aministrativo', 150),('03', 'Contable', 200),
('04', 'General', 300);

INSERT INTO personal VALUES ('1010100','Gómez Reina, Marcela', '01', 100.00,20),
('1212120','Peinado Guindilla, Eva', '01', 100.00,10),
('1313130','Maza Carpio, Susana','01', 100.00,10),
('1414140','Sevilla Pozo, Rosa', '02', 1200.00,20),
('1515150','Serena Linda, Remedios', '02', 1200.00,20),
('1616160','Cavas Estampa, Pura', '02', 1200.00,30),
('1717170','Perez Robles, Jaime','03', 1675.00,20),
('1818180','Corchete Muñoz, Carmen','03', 1675.00,40),
('1919190','Flores Gotas, Ana','03', 1600.00,30),
('2121212','Ramos Esparta, Pedro',NULL, 1600.00,30);

INSERT INTO categorias(cod_cat, nombre) VALUES ('CAR1','CARDIO'),
('COM1', 'COMBO'), ('YOG2', 'YOGA'), ('HIT1', 'HIT'); 


INSERT INTO monitores VALUES ('2222222','Azul Verdejo, Paula',50,'CAR1'),
('3333333','Verde Tocino, Clara',10,'CAR1'),
('4444444','Naranja Azul, Eva',10,'CAR1'),
('5555555','Verdasco Rojo, Violeta', 20,'YOG2'),
('6666666','Verde Sarmiento, Luis',20,'COM1'),
('7777777','Rosa Azulado, Dionisia',20,'YOG2'),
('8888888','Amarillo Petardo, David',30,'CAR1'),
('9999999','Rosa Precioso, Mercedes',40,'YOG2'),
('1111111','Azul Pardo, Luis',40,NULL);


COMMIT;

-- ******** FIN *