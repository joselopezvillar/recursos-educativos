#!/bin/bash
#set -o errexit
#set -o xtrace
set -o nounset
clear
date
echo "----- Escenario Alta disponibilidad: HAProxy -----"
echo "Seleccionar operación:"
echo "1. Crear escenario"
echo "2. Parar contenedores escenario"
echo "3. Arrancar contenedores escenario"
echo "4. Borrar escenario"
echo "------"
read opcion
case $opcion in
1) echo "Crear escenario"
		# Variables
		HAPROXY01_WAN="192.0.2.254"
		HAPROXY01_WEB="172.31.0.254"
		HAPROXY01_GW="192.0.2.1"
		RED_WEB="172.31.0"
        lxc project create sad-haproxy -c features.images=false -c features.profiles=true
        lxc project switch sad-haproxy
		# Creación redes y perfiles
		#creación red WAN
		lxc network create wan ipv4.address=192.0.2.1/24 ipv6.address=none ipv4.dhcp=true ipv4.dhcp.ranges="192.0.2.2-192.0.2.50" ipv4.firewall=true ipv4.nat=true
		#creación red WEB
		lxc network create web ipv4.address=172.31.0.1/16 ipv6.address=none ipv4.dhcp=true ipv4.dhcp.ranges="172.31.0.2-172.31.0.50" ipv4.firewall=true ipv4.nat=true
		# creación perfil WAN-WEB con 2 NICs en modo ponte
		lxc profile create WAN-WEB
		cat profile_WAN-WEB | lxc profile edit WAN-WEB
		# creación perfil WEB con 1 NICs en modo ponte
		lxc profile create WEB
		cat profile_WEB | lxc profile edit WEB
		# Creación máquinas HAProxys
		echo "------- HAPROXY  -------"
		echo " "
		lxc init ubuntu:f haproxy01 --profile WAN-WEB
		cp config.yml_2NICS_PLANTILLA config.yml
		sed -i "s/HOSTNAME/haproxy01/g" config.yml
		sed -i "s/FQDN/haproxy01.test/g" config.yml
		lxc config set haproxy01 user.user-data -< config.yml
		cp network.yaml_PLANTILLA network.yaml
		sed -i "s/XXXX/$HAPROXY01_WAN/g" network.yaml
		sed -i "s/YYYY/$HAPROXY01_WEB/g" network.yaml
		sed -i "s/ZZZZ/$HAPROXY01_GW/g" network.yaml
		lxc config set haproxy01 user.network-config -< network.yaml
		lxc start haproxy01
		# Creación servidores web
		echo "------- Cluster Web  -------"
		echo " "
        # importar imaxe webserver
        lxc image import alpine-php.tar.gz --alias=webserver-alpine-php
		for i in {1..5}
		do
			# seleccionar imagen para crear contenedor 
			lxc init webserver-alpine-php web0$i --profile WEB
			# personalizar configuración contenedor
			cp interfaces_PLANTILLA interfaces
			sed -i "s/XXXX/$RED_WEB.1$i/g" interfaces
			sed -i "s/YYYY/$RED_WEB.1/g" interfaces
			lxc file push interfaces web0$i/etc/network/interfaces
            lxc file push resolv.conf web0$i/etc/resolv.conf
			lxc start web0$i 
		done
		echo " "
		sleep 5
		lxc ls -c n,s,4,P,S,l
	;;
2) echo "Parar contenedores escenario"
   lxc project switch sad-haproxy
   lxc stop -f --all
   echo " "
   lxc ls -c n,s,4,P,S,l
   ;;
3) echo "Arrancar containers escenario"
   lxc project switch sad-haproxy
   lxc start --all
   echo " "
   lxc ls -c n,s,4,P,S,l,m
   ;;
4) echo "Borrar escenario"
   lxc project switch sad-haproxy
   lxc stop -f haproxy01
   lxc delete haproxy01
   for j in {1..5}
   do
     lxc stop -f web0$j
     lxc delete web0$j
   done
   lxc profile delete WAN-WEB
   lxc profile delete WEB
   #lxc network delete wan
   #lxc network delete web
   #lxc image delete webserver-alpine-php
   #
   echo " "
   lxc ls -c n,s,4,P,S,l,m
   lxc project delete sad-haproxy
   ;;
*) echo "opción incorrecta"
   ;;
esac
date
