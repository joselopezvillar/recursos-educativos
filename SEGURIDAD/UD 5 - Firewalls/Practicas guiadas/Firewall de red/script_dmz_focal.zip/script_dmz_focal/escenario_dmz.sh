#!/bin/bash
# - red wan --> 192.0.2.1/24
# - red lan --> 192.168.100.1/24
# - red dmz --> 172.16.0.1/16
# IPs fw-linux
WAN=192.0.2.254
GW=192.0.2.1
LAN=192.168.100.254
DMZ=172.16.255.254
# IPs server
SERVER=172.16.0.2
# IP contedor admin2
ADMIN2=192.168.100.2
alu="sad"
clear
date
echo "----- Escenario Firewall de red con DMZ -----"
echo "Seleccionar operación:"
echo "1. Crear escenario"
echo "2. Parar equipos"
echo "3. Arrancar equipos"
echo "4. Borrar escenario"
echo "------"
read opcion
case $opcion in
1) echo "Crear escenario"
   lxc project create FW-DMZ -c features.images=false -c features.profiles=true
   lxc project switch FW-DMZ
   lxc network create wan ipv4.address=192.0.2.1/24 ipv6.address=none ipv4.dhcp=true ipv4.dhcp.ranges="192.0.2.100-192.0.2.200" ipv4.firewall=true ipv4.nat=true
   lxc network create lan ipv4.address=192.168.100.1/24 ipv6.address=none ipv4.dhcp=true ipv4.dhcp.ranges="192.168.100.100-192.168.100.200" ipv4.firewall=true ipv4.nat=true
   lxc network create dmz ipv4.address=172.16.0.1/16 ipv6.address=none ipv4.dhcp=true ipv4.dhcp.ranges="172.16.0.100-172.16.0.200" ipv4.firewall=true ipv4.nat=true
   # creación perfil para firewall de rede
   lxc profile create 3NICs
   cat profile_3NICs | lxc profile edit 3NICs
   # creación perfil para red wan
   lxc profile create wan
   cat profile_wan | lxc profile edit wan
   # creación perfil para red lan
   lxc profile create lan
   cat profile_lan | lxc profile edit lan
   # creación perfil para red dmz
   lxc profile create dmz
   cat profile_dmz | lxc profile edit dmz
   echo " "
	# creación firewall de red
	echo "-------  firewall de red  -------"
	# crear contedor fw
	# escoller a imaxe que se desexe 
	lxc init ubuntu:f fw --profile 3NICs
	# personalizar a configuración de rede
    cp config.yml_PLANTILLA_FW config.yml
	sed -i "s/NOMBRE/$alu/g" config.yml
    sed -i "s/XXXX/$WAN/g" config.yml
	sed -i "s/YYYY/$GW/g" config.yml
	sed -i "s/WWWW/$LAN/g" config.yml
	sed -i "s/ZZZZ/$DMZ/g" config.yml
	lxc config set fw user.user-data -< config.yml
	# creación server DMZ
	echo " "
	echo "-------  server DMZ  -------"
	# crear contenedor serverdmz
	lxc init ubuntu:f serverdmz --profile dmz
	# personalizar a configuración de rede
    cp config.yml_PLANTILLA_DMZ config.yml
	sed -i "s/NOMBRE/$alu/g" config.yml
    sed -i "s/HOSTNAME/serverdmz/g" config.yml
    sed -i "s/FQDN/serverdmz.asi2r.local/g" config.yml
    sed -i "s/XXXX/$SERVER/g" config.yml
	sed -i "s/YYYY/$DMZ/g" config.yml
	lxc config set serverdmz user.user-data -< config.yml
	# creación server DMZ
	echo " "
	echo "-------  equipo admin2  -------"
	echo " "
	# crear contedor admin2
	# escoller a imaxe que se desexe 
	lxc init ubuntu:f admin2 --profile lan
	# personalizar a configuración de rede
    cp config.yml_PLANTILLA config.yml
	sed -i "s/NOMBRE/$alu/g" config.yml
    sed -i "s/HOSTNAME/admin2/g" config.yml
    sed -i "s/FQDN/admin2.asi2r.local/g" config.yml
    sed -i "s/XXXX/$ADMIN2/g" config.yml
    sed -i "s/YYYY/$LAN/g" config.yml
    lxc config set admin2 user.user-data -< config.yml
	# arrincando contedores
	echo " "
	echo "-------  Iniciando contenedores  ------"
	echo " "
	lxc start fw 
	lxc start serverdmz
	lxc start admin2
    echo " "
    echo " Aplicando configuración "
    echo " "
    sleep 5
	lxc ls -c n,s,4,P,S,l
	;;
2) echo "Parar contenedores escenario"
    lxc project switch FW-DMZ
	lxc stop -f --all
	lxc ls -c n,s,4,P,S,l
	echo " "
	;;
3) echo "Arrancar contenedores escenario"
    lxc project switch FW-DMZ
	lxc start --all
	sleep 3
	lxc ls -c n,s,4,P,S,l
	echo " "
	;;
4) echo "Borrar escenario"
    lxc project switch FW-DMZ
	lxc stop -f --all
	lxc delete fw serverdmz admin2
	lxc profile delete 3NICs
	lxc profile delete lan
	lxc profile delete wan
	lxc profile delete dmz
	lxc project delete FW-DMZ
    ;;
*) echo "Opción incorrecta"
	;;
esac
date
