#!/bin/bash
# lxc image import ee74cc583b13f500e671ee129aab8243f40b2104690bdc0234afc9ee67f0f951.tar.gz  --alias=alpine-apache-bind description="Serv. apache+php+BIND - Alpine/3.10"
WAN="198.51.100.254"
LAN="192.168.205.254"
DMZINT="10.255.255.254"
DMZEXT="172.27.0.254"
GW="198.51.100.1"
INT00="10.255.255.10"
SERVER01="172.27.0.10"
OPERARIO="192.168.205.11"
alu="sad"
clear
echo "----- Examen squid -----"
echo "Seleccionar a iptables:"
echo "1. Crear escenario"
echo "2. Parar contenedores escenario"
echo "3. Arrancar contenedores escenario"
echo "4. Borrar escenario"
echo "------"
read opcion
case $opcion in
1) echo "Crear escenario"
   lxc project create sad-iptables -c features.images=false -c features.profiles=true
   lxc project switch sad-iptables
   # importar imagen alpine
   lxc image import ee74cc583b13f500e671ee129aab8243f40b2104690bdc0234afc9ee67f0f951.tar.gz  --alias=alpine-apache-bind description="Serv. apache+php+BIND - Alpine/3.10"
   # creación redes
   lxc network create wan4 ipv4.address=198.51.100.1/24 ipv6.address=none ipv4.dhcp=true ipv4.dhcp.ranges="198.51.100.100-198.51.100.150" ipv4.firewall=true ipv4.nat=true
   lxc network create lan4 ipv4.address=192.168.205.1/24 ipv6.address=none ipv4.dhcp=true ipv4.dhcp.ranges="192.168.205.100-192.168.205.150" ipv4.firewall=true ipv4.nat=true   
   lxc network create int4 ipv4.address=10.255.255.1/24 ipv6.address=none ipv4.dhcp=true ipv4.dhcp.ranges="10.255.255.100-10.255.255.150" ipv4.firewall=true ipv4.nat=true   
   lxc network create ext4 ipv4.address=172.27.0.1/24 ipv6.address=none ipv4.dhcp=true ipv4.dhcp.ranges="172.27.0.100-172.27.0.150" ipv4.firewall=true ipv4.nat=true   
   # perfil red DMZINT
   lxc profile create int4
   cat profile_INT4 | lxc profile edit int4   
   # perfil red DMZEXT
   lxc profile create ext4
   cat profile_EXT4 | lxc profile edit ext4   
   # perfil red lan
   lxc profile create lan4
   cat profile_LAN4 | lxc profile edit lan4     
   # perfil firewall
   lxc profile create fw4
   cat profile_FW4 | lxc profile edit fw4  
   # contenedor firewall
   lxc init ubuntu:f sad-fw --profile fw4
   # personalizar a configuración do contedor
   cp config.yml_PLANTILLA config.yml
   sed -i "s/HOSTNAME/sad-fw/g" config.yml
   sed -i "s/FQDN/sad-fw.local/g" config.yml
   sed -i "s/NOMBRE/$alu/g" config.yml 
   sed -i "s/XXXX/$WAN/g" config.yml
   sed -i "s/YYYY/$GW/g" config.yml
   sed -i "s/VVVV/$LAN/g" config.yml
   sed -i "s/WWWW/$DMZINT/g" config.yml
   sed -i "s/ZZZZ/$DMZEXT/g" config.yml
   lxc config set sad-fw user.user-data -< config.yml
   # server01
   lxc init alpine-apache-bind sad-server01 --profile ext4
   cp interfaces_PLANTILLA interfaces
   sed -i "s/XXXX/$SERVER01/g" interfaces
   sed -i "s/YYYY/$DMZEXT/g" interfaces 
   lxc file push interfaces sad-server01/etc/network/interfaces
   lxc file push resolv.conf sad-server01/etc/resolv.conf
   # int00
   lxc init alpine-apache-bind sad-int00 --profile int4
   cp interfaces_PLANTILLA interfaces
   sed -i "s/XXXX/$INT00/g" interfaces
   sed -i "s/YYYY/$DMZINT/g" interfaces 
   lxc file push interfaces sad-int00/etc/network/interfaces
   lxc file push resolv.conf sad-int00/etc/resolv.conf

   # operario lan
   lxc init ubuntu:f sad-operario --profile lan4
   cp config.yml_OPERARIO config.yml
   sed -i "s/HOSTNAME/sad-operario/g" config.yml
   sed -i "s/FQDN/sad-operario.local/g" config.yml
   sed -i "s/NOMBRE/$alu/g" config.yml 
   sed -i "s/XXXX/$OPERARIO/g" config.yml
   sed -i "s/YYYY/$LAN/g" config.yml
   lxc config set sad-operario user.user-data -< config.yml
   lxc start sad-fw
   lxc start sad-server01
   lxc start sad-int00
   lxc start sad-operario
   ;;
2) echo "Parar contenedores escenario"
   lxc project switch sad-iptables
   lxc stop -f --all
   ;;
3) echo "Arrancar containers escenario"
   lxc project switch sad-iptables
   lxc start --all
   ;;
4) echo "Borrar escenario"
   lxc project switch sad-iptables
   lxc stop -f --all
   lxc delete -f sad-fw
   lxc delete -f sad-server01
   lxc delete -f sad-int00
   lxc delete -f sad-operario
   lxc profile delete int4
   lxc profile delete ext4
   lxc profile delete lan4
   lxc profile delete fw4
   lxc project delete sad-iptables
   ;;
*) echo "opción incorrecta"
   ;;
esac
