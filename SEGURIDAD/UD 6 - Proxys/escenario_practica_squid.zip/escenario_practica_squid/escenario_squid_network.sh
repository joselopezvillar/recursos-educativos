#!/bin/bash
#set -o errexit
#set -o xtrace
set -o nounset
clear
# Personalización del escenario
SQUID_WAN="192.0.2.254"
SQUID_LAN="192.168.100.254"
SQUID_GW="192.0.2.1"
RED_LAN="192.168.100"
RED_WAN="192.0.2"
CLIENTE="100"
echo "----- Escenario Squid -----"
echo "Seleccionar operación:"
echo "1. Crear escenario"
echo "2. Parar contenedores escenario"
echo "3. Arrancar contenedores escenario"
echo "4. Borrar escenario"
echo "------"
read opcion
case $opcion in
1) echo "Crear escenario"
        lxc project create sad-squid-test -c features.images=false -c features.profiles=true
        lxc project switch sad-squid-test
        # Creación redes y perfiles
        #creación red wan
        lxc network create wan ipv4.address=$RED_WAN.1/24 ipv6.address=none ipv4.dhcp=true ipv4.dhcp.ranges="$RED_WAN.2-$RED_WAN.50" ipv4.firewall=true ipv4.nat=true
        #creación red lan
        lxc network create lan ipv4.address=$RED_LAN.1/24 ipv6.address=none ipv4.dhcp=true ipv4.dhcp.ranges="$RED_LAN.2-$RED_LAN.50" ipv4.firewall=true ipv4.nat=true
        # creación perfil WAN-LAN con 2 NICs en modo ponte
        lxc profile create WAN-LAN
        cat profile_WAN-LAN | lxc profile edit WAN-LAN
        # creación perfil LAN con 1 NICs en modo ponte
        lxc profile create LAN
        cat profile_LAN | lxc profile edit LAN
        # Creación máquina Squid
        echo " "
        echo "------- Squid  -------"
        echo " "
        lxc init ubuntu:f squid --profile WAN-LAN
        cp config_2NICS_PLANTILLA.yml config.yml
        sed -i "s/HOSTNAME/squid/g" config.yml
        sed -i "s/FQDN/squid.test/g" config.yml
        cp network_2NICS_PLANTILLA.yml network.yml
        sed -i "s/XXXX/$SQUID_WAN/g" network.yml
        sed -i "s/YYYY/$SQUID_LAN/g" network.yml
        sed -i "s/ZZZZ/$SQUID_GW/g" network.yml      
        lxc config set squid user.user-data -< config.yml
        lxc config set squid user.network-config -< network.yml
        echo " " 
        echo "------- cliente .100  -------"
        echo " "        
        lxc init ubuntu:f cliente100 -p LAN
        cp config_CLIENTE.yml config.yml
        sed -i "s/HOSTNAME/cliente100/g" config.yml
        sed -i "s/FQDN/cliente100.test/g" config.yml
        cp network_CLIENTE.yml network.yml
        sed -i "s/XXXX/$RED_LAN.$CLIENTE/g" network.yml
        sed -i "s/ZZZZ/$RED_LAN.1/g" network.yml
        lxc config set cliente100 user.user-data -< config.yml
        lxc config set cliente100 user.network-config -< network.yml
        echo "------- Arranque squid+cliente  -------"
        echo " "        
        lxc start squid
        lxc start cliente100
        echo " "
        #lxc ls -c n,s,4,P,S,l,m
	;;
2) echo "Parar contenedores escenario"
   lxc project switch sad-squid-test
   lxc stop -f --all
   echo " "
   lxc ls -c n,s,4,P,S,l
   ;;
3) echo "Arrancar containers escenario"
   lxc project switch sad-squid-test
   lxc start --all
   echo " "
   lxc ls -c n,s,4,P,S,l
   ;;
4) echo "Borrar escenario"
   lxc project switch sad-squid-test
   lxc stop -f --all
   lxc delete squid cliente100
   lxc profile delete WAN-LAN
   lxc profile delete LAN
   #lxc network delete wan
   #lxc network delete lan
   echo " "
   lxc ls -c n,s,4,P,S,l
   lxc project delete sad-squid-test
   ;;
*) echo "opción incorrecta"
   ;;
esac
date
