<html>

<head>
   <title>IAW. Exame.</title>
</head>

<body>

<h1>Conversor de euros a pesetas</h1>

<?php

function validarEntero($valor){
   if(filter_var($valor, FILTER_VALIDATE_INT) === FALSE){
      return false;
   }else{
      return true;
   }
}

	// Uso de constante, pero se podría usar variable
   define ("euroapesetas", 166.386);

   $euros = $_REQUEST['euros'];

	/* Se podría hacer una comprobación más básica, pero no controlaría si introducimos texto
   if ($euros == "")
      print ("<p>Debe introducir una cantidad</p>");
	*/

   if (!validarEntero($euros))
      print ("<p>Debe introducir unha cantidade</p>");
   else
   {
      $pesetas = $euros*euroapesetas;
      print ("<p>$euros euro(s) equivale(n) a $pesetas pesetas</p>");
   }
?>

<p>
 <a href='conversor.php'>Voltar</a>
</p>

</body>
</html>
