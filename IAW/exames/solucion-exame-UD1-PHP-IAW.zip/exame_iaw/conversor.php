<html>

<head>
   <title>IAW. Exame.</title>
</head>

<body>

<H1>Conversor de euros a pesetas</H1>

<form action="conversor-resultados.php" method="POST">

<p>Cantidade en euros:
 <input type="text" name="euros" size="20"> <br><br>
 <input type="submit" name"enviar" value="convertir">
</p>

</form>

</body>
</html>
