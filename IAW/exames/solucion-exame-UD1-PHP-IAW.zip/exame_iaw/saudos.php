<html>

<head>
   <title>IAW. Exame. </title>
</head>

<body>

<h1>Saudamos!</h1>

<?php
   $nome = "Jose";
   $hora = date ("H");

   if ($hora >= 8 && $hora < 14)
      $saudo = "Bos d�as, ";
   else if ($hora >= 14 && $hora <= 21)
      $saudo = "Boas tardes, ";
   else
      $saudo = "Boas noites, ";
   $saudo = $saudo . $nome;
   print ($saudo);
?>

</body>
</html>
