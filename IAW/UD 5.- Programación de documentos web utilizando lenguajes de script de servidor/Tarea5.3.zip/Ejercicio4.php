<?php

    $contactos = array (
        array(
            "nombre"=>"Luis",
            "tlf"=>"673920304"
        ),
        array(
            "nombre"=>"Pepe",
            "tlf"=>"647392040"
        ),
        array(
            "nombre"=>"Fran",
            "tlf"=>"690504032"
        ),
    );

    // Imprimimos los números de teléfono.
    echo "Números de teléfono: ";
    foreach ($contactos as $contacto){
        echo $contacto["tlf"].", ";
    };
    echo "</br>";

    // Imprimimos los nombres.
    echo "Nombres: ";
    foreach ($contactos as $contacto){
        echo $contacto["nombre"].", ";
    };
    echo "</br>";

    // Creamos la función para comprobar si existe un usuario en el array
    function existe_usuario($nombre_usuario,$array){
        if (array_search($nombre_usuario, array_column($array, 'nombre')) !== FALSE){
            echo "El nombre $nombre_usuario EXISTE en el array";
        }
        else {
            echo "El nombre $nombre_usuario NO EXISTE en el array";
        };
    };

    // Comprobamos is existe el nombre Luis
    existe_usuario("Luis",$contactos);
    echo "</br>";

    // Comprobamos is existe el nombre Juan
    existe_usuario("Juan",$contactos);
    echo "</br>";

    // Creamos un array solo con los nombres
    foreach ($contactos as $contacto){
        $nombres[]=$contacto["nombre"];
    };
    echo implode(', ',$nombres);

    echo "</br>";

    // Ordenamos el array
    sort($nombres);
    echo implode(', ',$nombres);

?>
