<html>  
    <body>
        <form method="GET" action="Ejercicio3.php">
            <p>
                <label for="x">VALOR X</label>
                <br>
                <input type="number" name="x" required="required"/>
            </p>
            <p>
                <label for="x">VALOR Y</label>
                <br>
                <input type="number" name="y" required="required"/>
            </p>
            
            <p><label for="operacion">OPERACIÓN</label></p>
            <p>
                <input type="submit" name="operacion" value="sumar"/>
                <input type="submit" name="operacion" value="restar"/>
                <input type="submit" name="operacion" value="multiplicar"/>
                <input type="submit" name="operacion" value="dividir"/>
            </p>
                
            </br>

            <p><label for="resultado">RESULTADO</label></p>
                
            <?php
                if(isset($_GET["x"])&&($_GET["y"])&&($_GET["operacion"])){

                    switch ($_GET["operacion"]) {
                        case "sumar":
                            echo $_GET["x"]." + ".$_GET["y"]." = ".$_GET["x"]+$_GET["y"];
                            break;
                        case "restar":
                            echo $_GET["x"]." - ".$_GET["y"]." = ".$_GET["x"]-$_GET["y"];
                            break;
                        case "multiplicar":
                            echo $_GET["x"]." * ".$_GET["y"]." = ".$_GET["x"]*$_GET["y"];
                            break;
                        case "dividir":
                            echo $_GET["x"]." / ".$_GET["y"]." = ".$_GET["x"]/$_GET["y"];
                            break;
                    };   
                };
            ?>

        </form>
    </body>
</html>

