<?php

    session_start();

    if(!isset($_SESSION["ejercicio1"])) {
        $_SESSION["ejercicio1"]=0;
    };

    if ($_GET["operacion"] == "sumar") {
        $_SESSION["ejercicio1"]++;
    }
    elseif ($_GET["operacion"] == "restar") {
        $_SESSION["ejercicio1"]--;
    };

    echo $_SESSION["ejercicio1"];
    echo "</br>";
    echo '<a href="Ejercicio1.php?operacion=restar">Restar</a>'."   ".'<a href="Ejercicio1.php?operacion=sumar">Sumar</a>';

?>
