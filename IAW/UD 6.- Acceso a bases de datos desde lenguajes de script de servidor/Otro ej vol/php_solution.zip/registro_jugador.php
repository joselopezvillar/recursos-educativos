<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Jugador</title>
</head>

<body>
    <h1>Registra un nuevo jugador</h1>
    <form method="post" action="verificar_jugador.php">
        <p>
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre"/>
        </p>
        <p>
            <label for="nacionalidad">Nacionalidad</label>
            <input type="text" name="nacionalidad"/>
        </p>
        <p>
            <label for="posicion">Posición</label>
            <input type="text" name="posicion"/>
        </p>
        <p>
            <label for="dorsal">Dorsal</label>
            <input type="text" name="dorsal"/>
        </p>
        <p>
            <label for="equipo">Equipo</label>
            <select id="equipo" name="equipo"> 
                <?php
                    $conexion = mysqli_connect("localhost","root", "", "repaso");
                    $sql2= mysqli_query($conexion, "SELECT nombre FROM equipos");

                    while($datos = mysqli_fetch_assoc($sql2)){
                         echo "<option value='" . $datos['nombre'] . "'>" . $datos['nombre'] . "</option>";
                    }
                ?>
                </select>   
        </p>
        
        <input type="submit" value="Enviar"/>
    </form>    
</body>
</html>
