<?php
session_start();
unset($_SESSION['username']);
unset($_SESSION['rol']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>

<body>
    
    <h1>Inicio de sesión</h1>
    <form method="post" action="verificar_login.php">
        <p>
            <label for="username">Username</label>
            <input type="text" name="username"/>
        </p>
        <p>
            <label for="password">Password</label>
            <input type="password" name="password"/>
        </p>
        


        <input type="submit" value="Enviar"/>

    </form>    
</body>
</html>
