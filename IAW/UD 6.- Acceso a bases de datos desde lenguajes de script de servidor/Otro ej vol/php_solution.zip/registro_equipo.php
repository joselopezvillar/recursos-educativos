<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Equipo</title>
</head>

<body>
    <h1>Registra un nuevo equipo</h1>
    <form method="post" action="verificar_equipo.php">
        <p>
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre"/>
        </p>
        <p>
            <label for="pais">País</label>
            <input type="text" name="pais"/>
        </p>
        <p>
            <label for="estadio">Estadio</label>
            <input type="text" name="estadio"/>
        </p>
        <p>
            <label for="fundacion">Fundación</label>
            <input type="date" name="fundacion"/>
        </p>
        
        <input type="submit" value="Enviar"/>
    </form>    
</body>
</html>
