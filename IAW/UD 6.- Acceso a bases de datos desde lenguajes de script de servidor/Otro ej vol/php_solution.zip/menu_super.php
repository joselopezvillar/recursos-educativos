<?php
session_start();
if(empty($_SESSION['username'])){
    echo "No has iniciado sesión."; echo " "; echo " ";
    echo "<a href='login.php'>Volver a inicio</a>";
    exit();
}

if($_SESSION['rol'] == 'user'){
    header("Location: menu_user.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tienda</title>
</head>
<body>
    
    <table border=1>
        <tr>
            <th>Nombre</th>
            <th>País</th>
            <th>Estadio</th>
            <th>Fundación</th>
        </tr>

        <?php
           
            $conexion = mysqli_connect("localhost","root", "", "repaso");
            $sql2= mysqli_query($conexion, "SELECT * FROM equipos");

            while($datos = mysqli_fetch_assoc($sql2)){
                    echo "<tr>";
                        echo "<td>".$datos['nombre']."</td>";
                        echo "<td>".$datos['pais']."</td>";
                        echo "<td>".$datos['estadio']."</td>";
                        echo "<td>".$datos['fundacion']."</td>";
                        echo '<td><a href="plantilla.php?equipo='.$datos['nombre'].'"><button type="button">Plantilla</button></a></td>';
                    echo "</tr>";
                 
            } 
            
            
        ?>
   </table>
   <br>
   <a href="registro_equipo.php"><button type="button">Añadir equipo</button></a>';
   <a href="registro_jugador.php"><button type="button">Añadir jugador</button></a>';
   <a href="registro_usuario.php"><button type="button">Nuevo usuario</button></a>';
   <br>

</body>
</html>