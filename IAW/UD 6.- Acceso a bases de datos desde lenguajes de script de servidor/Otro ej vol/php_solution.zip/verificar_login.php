<?php
session_start();
$cont = 0;
$user = $_POST["username"];
$con = $_POST["password"];
$_SESSION['username'] = $user;


$conexion = mysqli_connect("localhost","root", "", "repaso");


$sql2= mysqli_query($conexion, "SELECT rol FROM usuarios WHERE username = '$user'");

while($datos = mysqli_fetch_assoc($sql2)){
        $_SESSION['rol'] = $datos['rol'];        
}


$sql3= mysqli_query($conexion, "SELECT * FROM usuarios");

while($datos = mysqli_fetch_assoc($sql3)){
    if($datos["username"] == $user and $datos["password"] == $con and $datos["rol"] == 'superuser' ){
            $cont++;
            header("Location: menu_super.php"); 
        }
    elseif($datos["username"] == $user and $datos["password"] == $con and $datos["rol"] == 'user'){
            $cont++;
            header("Location: menu_user.php"); 
    }
}   

if($cont == 0){
    header("Location: login.php");    
}    



?>
