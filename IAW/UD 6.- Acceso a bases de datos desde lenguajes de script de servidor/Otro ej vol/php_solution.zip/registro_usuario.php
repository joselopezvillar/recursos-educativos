<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Usuario</title>
</head>

<body>
    <h1>Registra un nuevo usuario</h1>
    <form method="post" action="verificar_usuario.php">
        <p>
            <label for="username">Username</label>
            <input type="text" name="username"/>
        </p>
        <p>
            <label for="password">Password</label>
            <input type="text" name="password"/>
        </p>
        <p>
            <label for="rol">Rol</label>
            <select id="rol" name="rol"> 
                <?php
                    $conexion = mysqli_connect("localhost","root", "", "repaso");
                    $sql2= mysqli_query($conexion, "SELECT rol FROM usuarios");

                    while($datos = mysqli_fetch_assoc($sql2)){
                         echo "<option value='" . $datos['rol'] . "'>" . $datos['rol'] . "</option>";
                    }
                ?>
                </select>   
        </p>
        <input type="submit" value="Enviar"/>
    </form>    
</body>
</html>