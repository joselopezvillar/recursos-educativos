<?php
$username = $_POST["username"];
$password = $_POST["password"];
$rol = $_POST["rol"];

$conexion = mysqli_connect("localhost","root", "", "repaso");


$sql = "INSERT INTO usuarios VALUES ('$username','$password','$rol')";
$insert = mysqli_query($conexion, $sql);

echo "Los datos del nuevo usuario se han insertado correctamente."; echo " ";
echo "<a href='login.php'>Regresar al inicio</a>";



?>