<?php
$nombre = $_POST["nombre"];
$nacionalidad = $_POST["nacionalidad"];
$posicion = $_POST["posicion"];
$dorsal = $_POST["dorsal"];
$equipo = $_POST["equipo"];

$conexion = mysqli_connect("localhost","root", "", "repaso");


$sql = "INSERT INTO jugadores VALUES ('$nombre','$nacionalidad','$posicion','$dorsal','$equipo')";
$insert = mysqli_query($conexion, $sql);

echo "Los datos del nuevo jugador se han insertado correctamente."; echo " ";
echo "<a href='menu_super.php'>Regresar al menú</a>";



?>