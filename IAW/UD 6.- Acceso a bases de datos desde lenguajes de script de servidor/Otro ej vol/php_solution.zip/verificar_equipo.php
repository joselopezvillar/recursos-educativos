<?php
$nombre = $_POST["nombre"];
$pais = $_POST["pais"];
$estadio = $_POST["estadio"];
$fundacion = $_POST["fundacion"];

$conexion = mysqli_connect("localhost","root", "", "repaso");


$sql = "INSERT INTO equipos VALUES ('$nombre','$pais','$estadio','$fundacion')";
$insert = mysqli_query($conexion, $sql);

echo "Los datos del nuevo equipo se han insertado correctamente."; echo " ";
echo "<a href='menu_super.php'>Regresar al menú</a>";



?>
