<?php
$equipo = $_GET['equipo'];
session_start();
if(empty($_SESSION['username'])){
    echo "No has iniciado sesión."; echo " "; echo " ";
    echo "<a href='login.php'>Volver a inicio</a>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plantilla</title>
</head>
<body>
    
<?php
    echo "<a>Filtrar por:</a>"; echo " "; echo " ";
    echo "<a href='filtrar_plantilla_desc.php?filtro=nombre&equipo=$equipo'>Nombre</a>"; echo " "; echo " ";
    echo "<a href='filtrar_plantilla_desc.php?filtro=dorsal&equipo=$equipo'>Dorsal</a>"; echo " "; echo " ";
    echo "<br>";
    echo "<br>";
    ?>

    <table border=1>
        <tr>
            <th>Nombre</th>
            <th>Nacionalidad</th>
            <th>Posición</th>
            <th>Dorsal</th>
        </tr>

        <?php
           
            $filtro = $_GET['filtro'];
            $conexion = mysqli_connect("localhost","root", "", "repaso");
            $sql2= mysqli_query($conexion, "SELECT * FROM jugadores WHERE equipo = '$equipo' ORDER BY $filtro");

            while($datos = mysqli_fetch_assoc($sql2)){
                    echo "<tr>";
                        echo "<td>".$datos['nombre']."</td>";
                        echo "<td>".$datos['nacionalidad']."</td>";
                        echo "<td>".$datos['posicion']."</td>";
                        echo "<td>".$datos['dorsal']."</td>";
                        
                    echo "</tr>";
                 
            } 
            
            
        ?>
   </table>

</body>
</html>