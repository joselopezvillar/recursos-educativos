    <head>
        <title>Novo Alumno</title>
    </head>
    <link rel="stylesheet" href="./css/style.css" type="text/css" media="all" />
	
    <body>
	<h1 class="center">Estado do rexistro dun novo alumno</h1>
	<?php
		include './database/conector.php';

		// Recollo os datos enviados a través do formulari 
		$codalum = $_POST['codalum'];
		$nombre = $_POST['nombre'];
		$direccion = $_POST['direccion'];
		$curso = $_POST['curso'];

		// Inserto los datos en BBDD
	    	$insert_alumno = "INSERT INTO alumnos 
	  		(codalumno, nombre, direccion, cursoId)
			VALUES($codalum, '$nombre', '$direccion', $curso);";


	if ($result = mysqli_query($conector, $insert_alumno)) {
	    echo "<h3 class='center'>Alumno " . $nombre ." creado correctamente."."<br></h3>";		    
	} else {
	    echo ("Non se puido rexistrar o alumno/a -> ". mysqli_error($conector))."<br><br>";
	}
	    
	?>
	<div class="center">
	    <form action="./forms/iaw06_insertaAlumnoForm.php">
		<input type="submit" value="Volver al formulario" />
	    </form>
	</div>
    </body>
</html>


