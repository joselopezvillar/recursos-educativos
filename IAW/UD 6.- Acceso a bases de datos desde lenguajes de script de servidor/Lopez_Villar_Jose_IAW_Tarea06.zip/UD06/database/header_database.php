<ul>
  <li><a class="active" href="../index.php"><i class="fa fa-home"> IES San Clemente</i></a> </li>
  <li><a href="../forms/iaw06_insertaAlumnoForm.php">Alta alumnos</a></li>
  <li><a href="../forms/iaw06_insertaCursoForm.php">Alta cursos</a></li>
  <li><a href="../forms/iaw06_insertaAsignaturaForm.php">Alta asignaturas</a></li>
  <li><a href="../forms/iaw06_insertaNotaForm.php">Alta notas</a></li>
  <li><a href="../iaw06_listado.php">Amosar datos</a></li>
  <li><a href="create_db_script.php">Crear base de datos</a></li>
  <li><a href="borrar_db_script.php">Borrar base de datos</a></li>
</ul>

