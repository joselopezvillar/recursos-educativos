<?php	    
        //Se definen valores de conexión (por si hubiera migración o cambio futuro)
	    define("HOST", "localhost");
	    define("USER", "root");
	    define("PASSWORD", "");
	    define("NOMBRE_BBDD", "iaw");
?>
