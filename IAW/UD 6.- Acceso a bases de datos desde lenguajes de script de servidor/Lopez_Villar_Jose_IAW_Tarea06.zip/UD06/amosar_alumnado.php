	<h2 class="center">Alumnado do centro</h2></br>

		<table id="alumnado">
    	<tr>
			<th> id </th>
			<th> codalumn </th>
			<th> nombre </th>
			<th> direccion </th>			
			<th> cursoId </th>
		</tr>
<?php
	
		// ALUMNOS
	    // Query hacia la tabla alumnos y la almaceno en una variable, con objeto de pasársela como argumento a la func mysqli_query, junto con el conector.
	    $qry_alum = "SELECT * FROM alumnos order by nombre";
	    $res_alum = mysqli_query($conector, $qry_alum);
		
	    // Itero os resultados. Cada volta do bucle for almacena o dato en $row
	    for ($i=0; $i < mysqli_num_rows($res_alum); $i++) {
	    
		$row = mysqli_fetch_row($res_alum);
	    
		// Itero de novo cun bucle for each para obter o valor de cada columna
		            foreach ($row as $value) {
			        echo "<td>". $value ."</td>";
		            }  
		        ?>	
	            </tr>
		</table>
		<?php
    		    } // Llave de cierre del bucle for exterior
		    mysqli_free_result($res_alum);
?>