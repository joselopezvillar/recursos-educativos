	<h2 class="center">Cursos do centro</h2></br>

		<table id="cursos">
    	<tr>
			<th> id </th>
			<th> curso </th>
			<th> nomcurso </th>
			<th> nomalumn </th>
		</tr>

	<?php
		// CURSOS
	    /* En este caso, el único cambio es que uso directamente un único bucle for con la función mysqli_fetch_array, el cual me devuelve un array de datos al cuál accedo al resultado de la columna que deseo mediante 'array subscript'.*/
	    $qry_cursos = "SELECT * FROM curso order by curso";
	    $res_cursos = mysqli_query($conector, $qry_cursos);

	    for ($i=0; $row = mysqli_fetch_array($res_cursos, MYSQLI_ASSOC); $i++){
	?>

	    <tr>
		<td><?php echo $row['id'];?></td>
		<td><?php echo $row['curso'];?></td>
		<td><?php echo $row['nomcurso'];?></td>
		<td><?php echo $row['numalumn'];?></td>
	    </tr>
	

	<?php
	   }
	   mysqli_free_result($res_cursos); 
	?>
	</table>
