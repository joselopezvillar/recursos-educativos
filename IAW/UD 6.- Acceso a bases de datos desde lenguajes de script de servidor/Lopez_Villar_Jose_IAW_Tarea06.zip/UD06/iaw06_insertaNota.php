    <head>
        <title>Notas</title>
    </head>
    <link rel="stylesheet" href="./css/style.css" type="text/css" media="all" />
	
    <body>
	<h1 class="center">Notas do alumno/a</h1>
	<?php
		include './database/conector.php';

		// Recollo os datos enviados a través do formulario      
		$codalum = $_POST['codalum'];
		$codasig = $_POST['codasig'];
		$eval = $_POST['eval'];
		$nota = $_POST['nota'];

		// Inserto os datos na BBDD
	    	$insert_nota = "INSERT INTO notas 
	  		(codalum, codasig, eval, nota)
			VALUES($codalum, $codasig, $eval, $nota);";


	if ($result = mysqli_query($conector, $insert_nota)) {
	    echo "<h3 class='center'>Nota del alumno " . $codalum ." gardada correctamente."."<br></h3>";
	} else {
	    echo ("Non se puido rexistrar a nota -> ". mysqli_error($conector))."<br><br>";
	}
	    
	?>
	<div class="center">
	    <form action="./forms/iaw06_insertaNotaForm.php">
		<input type="submit" value="Volver al formulario" />
            </form>
	</div>
    </body>
</html>
