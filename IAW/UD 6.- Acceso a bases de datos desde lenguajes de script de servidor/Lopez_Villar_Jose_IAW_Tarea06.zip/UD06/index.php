<!DOCTYPE html>
<html>
<head>
	<title>Principal</title>
	<link rel="stylesheet" href="./css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<?php include_once('header.php'); ?>

    <h1>Proxecto de IAW</h1>
	<h2>Aplicación CRUD en PHP </h2>
	<p>Curso académico 22/23 </p>
<?php include_once('footer.php'); ?>

</body>
</html>