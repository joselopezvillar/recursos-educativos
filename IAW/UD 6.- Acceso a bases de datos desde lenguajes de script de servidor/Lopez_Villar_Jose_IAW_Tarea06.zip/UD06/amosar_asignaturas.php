	<h2 class="center">Asignaturas do centro</h2></br>

		<table id="asignaturas">
		<tr>
			<th> id </th>
			<th> codasig </th>
			<th> nomasig </th>
			<th> horas </th>
			</tr>
		<tr>
				
	<?php
		// ASIGNATURAS
	    $qry_asig = "SELECT * FROM asignaturas order by nomasig";
	    $res_asig = mysqli_query($conector, $qry_asig);

	    for ($i=0; $i < mysqli_num_rows($res_asig); $i++) {
	    
		$row = mysqli_fetch_row($res_asig);
	    
		foreach ($row as $value) {
			echo "<td>". $value ."</td>";
		}
		?>	
	    </tr>
		</table>
		<?php
    		    } // Llave de cierre del bucle for exterior
		    mysqli_free_result($res_asig);
		?>
