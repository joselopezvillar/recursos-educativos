<html>
    <head>
        <title>Novo Curso</title>
    </head>
    <link rel="stylesheet" href="./css/style.css" type="text/css" media="all" />
	
    <body>
	<h1 class="center">Estado da solicitude</h1>
	<?php
		include './database/conector.php';

		// Recollo os datos enviados a través do formulario    
		$curso = $_POST['curso'];
		$nomcurso = $_POST['nomcurso'];
		$numalum = $_POST['numalum'];

		// Inserto os datos na BBDD
	    	$insert_curso = "INSERT INTO curso 
	  		(curso, nomcurso, numalumn)
			VALUES($curso, '$nomcurso', $numalum);";

		if ($result = mysqli_query($conector, $insert_curso)) {
		    echo "<h3 class='center'>Curso " . $nomcurso ." creado correctamente."."<br></h3>";
		} else {
		    echo ("Non se puido crear un novo curso. -> ". mysqli_error($conector))."<br><br>";
		}
	    
	?>
	<div class="center">
	    <form action="./forms/iaw06_insertaCursoForm.php">
		<input type="submit" value="Volver al formulario" />
	    </form>
	</div>
    </body>
</html>
