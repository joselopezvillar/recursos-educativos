<html>
    <head>
	<title>Novo alumnado</title>
    <link rel="stylesheet" href="../css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    </head>

    <body>
	<?php include_once('header_forms.php'); ?>

	<h1>Formulario</h1>
	<h2>Rexistro de novo alumnado</h2>

	<form method="POST" action="../iaw06_insertaAlumno.php">
	    Código do alumno:<br>
	    <input type="text" id="codalum" name="codalum" />
	    <br><br>
 
	    Nome:<br>
	    <input type="text" id="nombre" name="nombre" />
	    <br><br>

        Enderezo:<br>
	    <input type="text" id="direccion" name="direccion" />
	    <br><br>

        Curso:<br> 
	    <input type="text" id="curso" name="curso"/>
	    <br><br>

		<input type="submit" value="ENVIAR" />
		<input type="submit" value="LIMPAR" />

	</form>

<?php	include '../footer.php'; ?>

    </body>
    
</html>
