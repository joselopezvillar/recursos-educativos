<html>
    <head>
	<title>Nova asignatura</title>
    <link rel="stylesheet" href="../css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    </head>
	
    <body>
	<?php include_once('header_forms.php'); ?>

	<h1>Formulario</h1>
	<h2>Rexistro de nova asignatura</h2>	

	<form method="POST" action="../iaw06_insertaAsignatura.php">

            Código da asignatura:<br> 
	    <input type="text" id="codasig" name="codasig"/>
	    <br><br>

            Nome da asignatura:<br> 
	    <input type="text" id="nomasig" name="nomasig"/>
	    <br><br>

            Horas da asignatura:<br> 
	    <input type="text" id="horas" name="horas"/>
	    <br><br>

		<input type="submit" value="ENVIAR" />
		<input type="submit" value="LIMPAR" />

	</form>
	
<?php	include '../footer.php'; ?>


    </body>
    
</html>
