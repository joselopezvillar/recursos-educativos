<html>
    <head>
	<title>Resultados</title>
	<link rel="stylesheet" href="./css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
	
	<?php include_once('header.php'); ?>
    <?php include './database/conector.php'; ?>

    <body>

	<?php
	if ($estado_de_la_conexion == 0){ 	
		echo '<h1 class="center">Datos por categoría</h1></br>';
		include_once('amosar_alumnado.php'); 
		include_once('amosar_cursos.php'); 
		include_once('amosar_asignaturas.php'); 
		include_once('amosar_notas.php'); 
	}
	else{
		echo "No se pudo conectar a la base de datos para consultar datos";
	}
	include_once('footer.php');

	 ?>

    </body>
</html>
