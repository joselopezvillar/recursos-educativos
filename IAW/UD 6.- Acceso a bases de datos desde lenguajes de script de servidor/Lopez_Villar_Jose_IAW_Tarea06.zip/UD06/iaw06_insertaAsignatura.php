    <head>
        <title>Asignaturas</title>
    </head>
    <link rel="stylesheet" href="./css/style.css" type="text/css" media="all" />
	
    <body>
	<h1 class="center">Nova asignatura</h1>
	<?php
		include './database/conector.php';

		// Recollo os datos enviados a través do formulario    
		$codasig = $_POST['codasig'];
		$nomasig = $_POST['nomasig'];
		$horas = $_POST['horas'];

		// Inserto os datos na BBDD
	    	$insert_asig = "INSERT INTO asignaturas 
	  		(codasig, nomasig, horas)
			VALUES($codasig, '$nomasig', $horas);";

	if ($result = mysqli_query($conector, $insert_asig)) {
	    echo "<h3 class='center'>Asignatura " . $nomasig ." creada correctamente."."<br></h3>";  		    
	} else {
	    echo ("Non se puido rexistrar a asignatura  -> ". mysqli_error($conector))."<br><br>";
	}
	    
	?>
	<div class="center">
	    <form action="./forms/iaw06_insertaAsignaturaForm.php">
		<input type="submit" value="Volver al formulario" />
	    </form>
	</div>
    </body>
</html>
