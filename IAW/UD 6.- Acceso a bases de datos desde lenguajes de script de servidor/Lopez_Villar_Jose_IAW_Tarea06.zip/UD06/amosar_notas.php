	<?php// Notas ?>
	<h2 class="center">Notas dos alumnado</h2></br>

		<table id="notas">
    	<tr>
			<th> id </th>
			<th> codalumn </th>
			<th> codasig </th>
			<th> eval </th>			
			<th> nota </th>
		</tr>
	<?php

	    $qry_nota = "SELECT * FROM notas order by codasig";
	    $res_nota = mysqli_query($conector, $qry_nota);

	    for ($i=0; $i < mysqli_num_rows($res_nota); $i++) {
	    
		$row = mysqli_fetch_row($res_nota);

		foreach ($row as $value) {
	        echo "<td>". $value ."</td>";
		}
		?>	
	    </tr>
		</table>
	    <?php
    	        } // Llave de cierre del bucle for exterior
	        mysqli_free_result($res_nota);
		?>