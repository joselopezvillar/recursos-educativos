<h2 align="left" ><a  href="muestraProductos.php"><button type='button'>Volver al menú de compra</button></a></h2>
<?php
session_start();
$conexion=mysqli_connect('localhost', 'root', '', 'examen');

//OPCIÓN CON UNA CONSULTA MÁS COMPLICADA Y UN SOLO BUCLE
if(isset($_SESSION["user"])){
    $user=$_SESSION["user"];
    $sql="SELECT * from pedidos, linea_pedido,productos where pedidos.usuario = '$user' and pedidos.idPedido = linea_pedido.idPedido and linea_pedido.idProducto=productos.id";
$result=mysqli_query($conexion,$sql);
$idpedido=0;
while($mostrar=mysqli_fetch_assoc($result)){
?>
                
                <table border="1">
            <tr>
                <th>idPedido</th>
                <th>Categoría</th>
                <th>Color</th>
                <th>Marca</th>
                <th>Precio</th>             
</tr>


                
                <tr>
                <td><?php echo $mostrar['idPedido'] ?></td>
                <td><?php echo $mostrar['categoria'] ?></td> 
                <td><?php echo $mostrar['color'] ?></td> 
                <td><?php echo $mostrar['marca'] ?></td>
                <td><?php echo $mostrar['precio']."€" ?></td>
                
                
            </tr>

            <?php if($idpedido!=$mostrar["idPedido"]){
                    echo "<br><br>";
                    $idpedido = $mostrar["idPedido"];
                    }?>

            <?php
}
}

// OPCIÓN CON CONSULTAS MÁS SENCILLAS Y BUCLES ANIDADOS
/*
   if(isset($_SESSION["user"])){
    $user=$_SESSION["user"];
    $sql="SELECT * from pedidos where usuario = '$user'";
$result=mysqli_query($conexion,$sql);

while($mostrar=mysqli_fetch_array($result)){
?>
                <table border="1">
            <tr>
                <th>idPedido</th>
                <th>Categoría</th>
                <th>Color</th>
                <th>Marca</th>
                <th>Precio</th>             
</tr>
                <?php $pedido = $mostrar["idPedido"];
                $sql2 = "SELECT * from linea_pedido where idPedido = '$pedido'";
                $resultado=mysqli_query($conexion,$sql2);
                while($lineas=mysqli_fetch_array($resultado)){
                    
                    $idProducto=$lineas["idProducto"];
                    $sql3 = "SELECT * from productos where id = '$idProducto'";
                $res=mysqli_query($conexion,$sql3);
                while($productos=mysqli_fetch_array($res)){                   
                ?>
                
<tr>
                <td><?php echo $mostrar['idPedido'] ?></td>
                <td><?php echo $productos['categoria'] ?></td> 
                <td><?php echo $productos['color'] ?></td> 
                <td><?php echo $productos['marca'] ?></td>
                <td><?php echo $productos['precio']."€" ?></td>
                <br>
                
            </tr>
<?php
}
} 
}
}*/