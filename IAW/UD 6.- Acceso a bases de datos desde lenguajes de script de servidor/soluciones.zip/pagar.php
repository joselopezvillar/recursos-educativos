<?php

session_start();
$conexion=mysqli_connect('localhost', 'root', '', 'examen');



$usuario = $_SESSION["user"];
$sql="INSERT into pedidos values (NULL,'$usuario')";
mysqli_query($conexion,$sql);

$sql2="SELECT MAX(idPedido) FROM `pedidos` ";
$resultado=mysqli_query($conexion,$sql2);

while($mostrar=mysqli_fetch_array($resultado)){
    $idPedido=$mostrar[0];
}

foreach($_SESSION["carrito"] as $indice => $valor){
    $idProducto=$valor["id"];
    $sql3="INSERT INTO linea_pedido values ('$idPedido', '$idProducto')";
    mysqli_query($conexion,$sql3);
}
unset($_SESSION["carrito"]);
echo "<h1>Pedido realizado con éxito</h1>";

echo "<a href='muestraProductos.php?'><button type='button'>Volver al menú de compra</button></a>"



?>