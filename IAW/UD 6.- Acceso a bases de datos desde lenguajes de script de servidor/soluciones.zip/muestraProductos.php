<?php

// Se realiza la conexion a la base de datos
session_start();
$conexion=mysqli_connect('localhost', 'root', '', 'examen');

?>

<html>
    <body>
    <h2 align="right" ><a  href="carrito.php"><button type='button'>Carrito</button></a></h2>
    <h2 align="right" ><a  href="pedidos.php"><button type='button'>Pedidos</button></a></h2>
    <a href="muestraProductos.php?categoria=camiseta">Camisetas</a>
    <a href="muestraProductos.php?categoria=pantalon">Pantalones</a>
    <a href="muestraProductos.php?categoria=sudadera">Sudaderas</a>
        <br><br>
        <table border="1">
            <tr>
                <th>Categoría</th>
                <th>Color</th>
                <th>Marca</th>
                <th>Precio</th>
                <th>Opción</th>
</tr>

<?php
if(isset($_GET["categoria"])){
    $categoria=$_GET["categoria"];
    $sql="SELECT * from productos where categoria = '$categoria'";
$result=mysqli_query($conexion,$sql);

while($mostrar=mysqli_fetch_array($result)){
?>
<tr>
                <td><?php echo $mostrar['categoria'] ?></td>
                <td><?php echo $mostrar['color'] ?></td> 
                <td><?php echo $mostrar['marca'] ?></td>
                <td><?php echo $mostrar['precio']."€" ?></td>
                <?php $id=$mostrar["id"]?>
                <td><?php echo "<a href='accion.php?id=$id&categoria=$categoria'><button type='button'>Añadir</button></a>"?></td>
            </tr>
<?php
}

}
else{
// Se obtiene el contenido de la tabla alumnos

$sql="SELECT * from productos";
$result=mysqli_query($conexion,$sql);

while($mostrar=mysqli_fetch_array($result)){
?>
<tr>
                <td><?php echo $mostrar['categoria'] ?></td>
                <td><?php echo $mostrar['color'] ?></td> 
                <td><?php echo $mostrar['marca'] ?></td>
                <td><?php echo $mostrar['precio']."€" ?></td>
                <?php $id=$mostrar['id']?>
                <td><?php echo "<a href='accion.php?id=$id'><button type='button'>Añadir</button></a>"?></td>
</tr>
<?php
}
}
?>
</table>
</body>
</html>
