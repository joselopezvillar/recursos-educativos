<?php
session_start();
$conexion=mysqli_connect('localhost', 'root', '', 'examen');

    $id=$_GET["id"];
    $sql="SELECT * from productos where id = '$id'";
    $result=mysqli_query($conexion,$sql);


while($mostrar=mysqli_fetch_assoc($result)){
   
    $_SESSION["carrito"][]=array(
        "id"=>$mostrar["id"],
        "categoria"=>$mostrar["categoria"],
        "color"=>$mostrar["color"],
        "marca"=>$mostrar["marca"],
        "precio"=>$mostrar["precio"]
    );
}
if(isset($_GET["categoria"])){
    $categoria=$_GET["categoria"];
header("Location: muestraProductos.php?categoria=$categoria");
}
else{
    header("Location: muestraProductos.php");
}




?>