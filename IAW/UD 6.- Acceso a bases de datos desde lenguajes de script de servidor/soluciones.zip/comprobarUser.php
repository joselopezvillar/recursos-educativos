<?php
session_start();
$conexion=mysqli_connect('localhost', 'root', '', 'examen');

if(isset($_POST["email"]) && isset($_POST["password"])){
    $email=$_POST["email"];
    $password = $_POST["password"];
    $sql="SELECT * from usuarios where email = '$email' and password = '$password' ";
$result=mysqli_query($conexion,$sql);
if(mysqli_num_rows($result)>0){
    while($datos = mysqli_fetch_assoc($result)){
        $_SESSION["user"]=$datos["email"];
    }
    header("Location: muestraProductos.php");
}
else{
    header("Location: prueba.php");
}
}
else{
    header("Location: prueba.php");
}
?>