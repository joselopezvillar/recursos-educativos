<html>
<body>
<form method="POST" action="comprobarUser.php">
    <p>
        <label for="email">Correo:</label>
        <input type="email" name="email">
    </p>
    <p>
    <label for="password">Contraseña:</label>
        <input type="password" name="password">
    </p>
   
    <button type="submit" name="submit">Enviar</button>
</form>
</body>
</html>