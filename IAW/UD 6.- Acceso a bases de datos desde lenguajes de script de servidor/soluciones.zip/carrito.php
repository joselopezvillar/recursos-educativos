


<?php
session_start();
if(isset($_SESSION["carrito"])){
    ?>
    <table >
            <tr>
                <th>Categoría</th>
                <th>Color</th>
                <th>Marca</th>
                <th>Precio</th>
</tr>
    
    <?php
    $total=0;

    foreach($_SESSION["carrito"] as $indice => $valor){
        echo "<tr>";
        echo "<td>".$valor["categoria"]."</td>";
        echo "<td>".$valor["color"]."</td>";
        echo "<td>".$valor["marca"]."</td>";
        echo "<td>".$valor["precio"]."€</td>";
        echo "</tr>";
        $total = $total+$valor["precio"];
    }
    echo $total."€  ";
    echo "<a href='pagar.php'><button type='button'>Pagar</button></a>";
}



else{

    echo "<h1>El carrito está vacío</h1>";
    
    
}



?>